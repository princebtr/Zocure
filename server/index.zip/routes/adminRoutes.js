// routes/adminRoutes.js
const express = require("express");
const router = express.Router();
const { addDoctor } = require("../controllers/adminController");
const { verifyToken, checkRole } = require("../middleware/authMiddleware");

// Apply verifyToken first, then check role
router.post("/add-doctor", verifyToken, checkRole(["admin"]), addDoctor);

module.exports = router;
