const express = require("express");
const router = express.Router();
const { verifyToken, checkRole } = require("../middleware/authMiddleware");
const doctorController = require("../controllers/doctorController");

// Admin routes for managing doctors
router.post("/add", verifyToken, checkRole(["admin"]), doctorController.addDoctor);
router.get("/all", doctorController.getAllDoctors);
router.get("/:id", doctorController.getDoctorById);

// Doctor routes
router.put("/update-slots", verifyToken, checkRole(["doctor"]), doctorController.updateSlots);
router.get("/my-appointments", verifyToken, checkRole(["doctor"]), doctorController.getMyAppointments);

module.exports = router;